(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_009834a2._.js",
  "static/chunks/app_4315ec63._.css"
],
    source: "dynamic"
});
