(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9dde9326._.js",
  "static/chunks/app_login_87825442._.css"
],
    source: "dynamic"
});
