(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_fd030f99._.js",
  "static/chunks/app_crm_customers_6397d54d._.css"
],
    source: "dynamic"
});
