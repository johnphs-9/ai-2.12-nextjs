(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_5d62c873._.js",
  "static/chunks/app_components_68c4ba58._.js",
  "static/chunks/app_341aa8f9._.css"
],
    source: "dynamic"
});
