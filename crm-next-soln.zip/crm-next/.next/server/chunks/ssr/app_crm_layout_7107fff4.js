module.exports = [
"[project]/app/crm/layout.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_crm_layout_7107fff4.js.map