module.exports = [
"[project]/app/crm/customers/error.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_crm_customers_error_8325ff4a.js.map