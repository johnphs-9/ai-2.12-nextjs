module.exports = [
"[project]/app/crm/customers/loading.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=app_crm_customers_loading_36ac45f5.js.map